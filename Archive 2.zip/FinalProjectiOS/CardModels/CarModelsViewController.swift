//
//  CarModelsViewController.swift
//  FinalProjectiOS
//
//  Created by Gi Oo on 27.12.21.
//

import UIKit

class CarModelsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func didClickMercedes(_ sender: Any) {
        let vc = UIStoryboard.init(name: "SpecificCarViewControllerStoryboard", bundle: Bundle.main).instantiateViewController(withIdentifier: "SpecificCarViewController") as? SpecificCarViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
