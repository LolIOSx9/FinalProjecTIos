//
//  SpecificCarTableViewCell.swift
//  FinalProjectiOS
//
//  Created by Gi Oo on 27.12.21.
//

import UIKit

class SpecificCarTableViewCell: UITableViewCell {

    @IBOutlet weak var modelNameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
