//
//  SpecificCarViewController.swift
//  FinalProjectiOS
//
//  Created by Gi Oo on 27.12.21.
//

import UIKit

class SpecificCarViewController: UIViewController {

    @IBOutlet weak var modelsTableView: UITableView!
    let image = UIImage()
    var modelsArray = [Cars]()
    override func viewDidLoad() {
        super.viewDidLoad()
        getDataFromWeb()
    }
    func getDataFromWeb(){
    let urlString = "https://private-anon-a41c950c16-carsapi1.apiary-mock.com/cars?fbclid=IwAR0wRAgw30gahMQTh1CZxZQf2lwSpp2VJRwsvDRDaxf_HGhMydrovMhgZV4"
    let url = URL(string: urlString)
    URLSession.shared.dataTask(with: url!){(data, _, _) in
        guard let data = data else {return}
        let result = try? JSONDecoder().decode([Cars].self, from: data)
        if result != nil{
            self.modelsArray = result!
            DispatchQueue.main.async {
                self.modelsTableView.reloadData()
            }
        }
    }.resume()
       
    }
    
    }

extension SpecificCarViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        modelsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SpecificCarTableViewCell", for: indexPath) as! SpecificCarTableViewCell
        cell.layer.cornerRadius = 20
        cell.layer.borderWidth = 1
        let currentModel = modelsArray[indexPath.row]
        cell.modelNameLabel.text = currentModel.make
        return cell
    }
    
    
}
